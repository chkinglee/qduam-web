create view stu_assn as
  select `qduam`.`student`.`ID`    AS `STUID`,
         `qduam`.`assn`.`ID`       AS `ID`,
         `qduam`.`assn`.`LOGNAME`  AS `LOGNAME`,
         `qduam`.`assn`.`ASSNNAME` AS `ASSNNAME`,
         `qduam`.`assn`.`DIRECTOR` AS `DIRECTOR`,
         `qduam`.`assn`.`PHONE`    AS `PHONE`,
         `qduam`.`assn`.`LEVEL`    AS `LEVEL`
  from (((`qduam`.`member` join `qduam`.`student` on ((`qduam`.`member`.`STUID` =
                                                       `qduam`.`student`.`ID`))) join `qduam`.`depart` on ((
    `qduam`.`member`.`DEPID` = `qduam`.`depart`.`ID`))) join `qduam`.`assn` on ((`qduam`.`depart`.`ASSNID` =
                                                                                 `qduam`.`assn`.`ID`)));

