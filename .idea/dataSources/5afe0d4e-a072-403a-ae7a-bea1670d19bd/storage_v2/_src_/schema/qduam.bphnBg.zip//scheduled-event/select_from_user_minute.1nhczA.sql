create definer = root@localhost event select_from_user_minute
  on schedule
    every '5' MINUTE
      starts '2018-05-24 14:07:05'
  on completion preserve
  enable
do
  SELECT * FROM `user`;

