create trigger delStu
  after DELETE
  on student
  for each row
  begin
delete from user where user.logname=old.logname;
-- 删除user表中该学生用户
end;

