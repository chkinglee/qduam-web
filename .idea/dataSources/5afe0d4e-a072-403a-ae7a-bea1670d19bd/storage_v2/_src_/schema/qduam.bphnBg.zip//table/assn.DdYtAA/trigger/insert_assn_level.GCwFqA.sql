create trigger insert_assn_level
  after INSERT
  on assn
  for each row
  begin
update assn set level = new.id where id = new.id;
end;

