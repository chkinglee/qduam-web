create trigger addStu
  after INSERT
  on student
  for each row
  begin
insert into user(logname,name,type,pic) values(new.logname,new.name,'1',concat(new.logname, '.jpg'));
-- 向user表中插入一条学生用户
end;

