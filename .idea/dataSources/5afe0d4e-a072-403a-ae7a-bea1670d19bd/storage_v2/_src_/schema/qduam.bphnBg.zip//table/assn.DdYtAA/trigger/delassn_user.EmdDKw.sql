create trigger delAssn_user
  after DELETE
  on assn
  for each row
  begin
delete from user where user.logname like (concat(old.logname,'%')) and user.type='2';
-- 删除user表中社团中所有部门用户
end;

