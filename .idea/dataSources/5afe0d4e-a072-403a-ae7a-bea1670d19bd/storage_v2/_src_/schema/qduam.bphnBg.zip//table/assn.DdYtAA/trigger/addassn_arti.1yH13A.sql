create trigger addAssn_arti
  after INSERT
  on assn
  for each row
  begin
insert into article(title,content,author,time,sectiona,sectionb) 
values(
concat(new.assnname,'简介'),
'暂无',
(select user.id from user where user.name=(concat(new.assnname,'主席团'))),
'暂无',
'2',
new.level
);
-- 向article表中插入一条 作者为 xxx主席团 的社团简介
end;

