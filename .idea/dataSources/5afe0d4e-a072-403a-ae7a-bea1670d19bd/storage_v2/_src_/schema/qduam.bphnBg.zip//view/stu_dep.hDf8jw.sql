create view stu_dep as
  select `qduam`.`student`.`ID`     AS `STUID`,
         `qduam`.`depart`.`ID`      AS `ID`,
         `qduam`.`depart`.`ASSNID`  AS `ASSNID`,
         `qduam`.`depart`.`LOGNAME` AS `LOGNAME`,
         `qduam`.`depart`.`DEPNAME` AS `DEPNAME`,
         `qduam`.`depart`.`LEVEL`   AS `LEVEL`,
         `qduam`.`depart`.`INTRO`   AS `INTRO`
  from ((`qduam`.`depart` join `qduam`.`member` on ((`qduam`.`member`.`DEPID` =
                                                     `qduam`.`depart`.`ID`))) join `qduam`.`student` on ((
    `qduam`.`member`.`STUID` = `qduam`.`student`.`ID`)));

