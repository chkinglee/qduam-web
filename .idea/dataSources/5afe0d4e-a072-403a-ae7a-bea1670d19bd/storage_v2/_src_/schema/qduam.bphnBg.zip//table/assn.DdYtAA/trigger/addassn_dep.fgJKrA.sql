create trigger addAssn_dep
  after INSERT
  on assn
  for each row
  begin
insert into depart(assnid,logname,depname,level) values(new.id,concat(new.logname,'00'),'主席团','1');
-- 向depart表中插入名为 xxx主席团 的部门
end;

