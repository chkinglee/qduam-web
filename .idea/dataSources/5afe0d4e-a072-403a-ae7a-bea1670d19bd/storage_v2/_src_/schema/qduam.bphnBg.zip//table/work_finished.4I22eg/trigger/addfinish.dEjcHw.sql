create trigger addFinish
  after INSERT
  on work_finished
  for each row
  begin
update work_released a
set a.num=a.num+1
where a.id=new.workid;
-- 更新work_released表中num字段，每插入一条完成信息，num+1
end;

