create trigger enroll_addMem
  after UPDATE
  on enroll
  for each row
  begin
if (new.status='4')
then
insert into member(stuid,depid,status)
values(old.stuid,old.depid,'1');
end if;
-- 如果报名状态为‘复试通过’ 则向member表中插入一条部员信息
end;

