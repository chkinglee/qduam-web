create view assn_article as
  select `qduam`.`user`.`LOGNAME`     AS `LOGNAME`,
         `qduam`.`article`.`ID`       AS `ID`,
         `qduam`.`article`.`TITLE`    AS `TITLE`,
         `qduam`.`article`.`CONTENT`  AS `CONTENT`,
         `qduam`.`article`.`AUTHOR`   AS `AUTHOR`,
         `qduam`.`article`.`TIME`     AS `TIME`,
         `qduam`.`article`.`SECTIONA` AS `SECTIONA`,
         `qduam`.`article`.`SECTIONB` AS `SECTIONB`
  from (`qduam`.`article` join `qduam`.`user` on ((`qduam`.`article`.`AUTHOR` = `qduam`.`user`.`ID`)));

