create trigger addDep
  after INSERT
  on depart
  for each row
  begin
insert into user(logname,name,type,pic) 
select new.logname,concat(b.assnname,new.depname),'2',concat(b.logname,'00.jpg')
from depart a
left join assn b on b.id=new.assnid
where a.id=new.id;
-- 向user表中插入一条部门用户 名称为 社团名+部门名 
end;

