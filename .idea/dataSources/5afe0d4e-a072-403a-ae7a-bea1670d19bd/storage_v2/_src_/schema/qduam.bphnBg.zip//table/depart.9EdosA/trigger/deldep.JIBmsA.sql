create trigger delDep
  after DELETE
  on depart
  for each row
  begin
delete from user where user.logname=old.logname;
-- 删除user表中该部门用户
end;

